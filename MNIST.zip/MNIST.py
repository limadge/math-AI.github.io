# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 20:06:10 2020

@author: ibf
"""
import tensorflow as tf
from tensorflow.examples.tutorials.mnist import input_data#数据集得导入
import pylab    #matplotlib提供得一个交互式得话图库
mnist=input_data.read_data_sets("MNIST_data",one_hot=True) #数据得导入，one_hot对标签进行亚编码
print('输入数据：',mnist.train.images)
print('输入数据得shape：',mnist.train.images.shape)
print('测试数据得shape：',mnist.test.images)
print('验证数据得shape：',mnist.validation.images.shape)
print('标签值shape:',mnist.train.labels.shape)
im=mnist.train.images[1]#查看一下第一个image
im=im.reshape(-1,28)
pylab.imshow(im)  #绘制图片
pylab.show()

#分析图片得特点
tf.reset_default_graph()#重置计算图
x=tf.placeholder(tf.float32,[None,784])#MNIST数据集得维度28*28=784
y=tf.placeholder(tf.float32,[None,10]) #总共10个类别

#定义参数
W=tf.Variable(tf.random_normal(([784,10])))
b=tf.Variable(tf.zeros([10]))
pred=tf.nn.softmax(tf.matmul(x,W)+b)#softmax分类

#损失函数批量梯度下降法
cost=tf.reduce_mean(-tf.reduce_sum(y*tf.log(pred),reduction_indices=1))
#定义参数
learning_rate=0.01

#使用梯度下降优化器
optimizer=tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)

#训练模型
training_epochs=25#把整个训练样本迭代25次
batch_size=100#训练过程中每次抽取100个数据
display_step=1#梅训练一次就把中间的显示出来

#启动session
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())#Initializing OP
     
    #启动循环开始训练
    for epoch in range(training_epochs):
        avg_cost=0.
        total_batch=int(mnist.train.num_examples/batch_size)
        
        #循环所有的数据集
        for i in range (total_batch):
            batch_xs,batch_ys=mnist.train.next_batch(batch_size)
            #运行优化器
            _,c=sess.run([optimizer,cost],feed_dict={x:batch_xs,y:batch_ys})
            
            #计算平均的loss
            avg_cost+=c/total_batch
            #显示训练中的详细信息
            if (epoch+1)%display_step==0:
                print("Epoch:",'%04d'%(epoch+1),"cost=","{:.9f}".format(avg_cost))
                
                
        print("Finished!")
             
        
#测试模
correct_prediction=tf.equal(tf.argmax(pred,1),tf.arg_max(y,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction,tf.float32))
with tf.Session() as sess:
    init = tf.global_variables_initializer()   #变量初始化
    sess.run(init)
    accu_test = sess.run(accuracy,feed_dict={x:mnist.test.images,y:mnist.test.labels})
print("Test Accuracy:",accu_test)

#模型的保存
with tf.Session() as sess:
    init = tf.global_variables_initializer()   #变量初始化
    sess.run(init)
    saver=tf.train.Saver()
    model_path="log/521model.ckpt"
    save_path=saver.save(sess,model_path)
print("model saved in file: %s" % save_path)

#模型的调用
print("Starting 2nd session....")
with tf.Session() as sess:
    init=tf.global_variables_initializer()
    sess.run(init)
    saver.restore(sess,model_path)
    
#测试model
correct_prediction=tf.equal(tf.argmax(pred,1),tf.arg_max(y,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction,tf.float32))
with tf.Session() as sess:
    init=tf.global_variables_initializer()
    sess.run(init)
    accu_test = sess.run(accuracy,feed_dict={x:mnist.test.images,y:mnist.test.labels})  
print("Test Accuracy:",accu_test)

with tf.Session() as sess:
    init=tf.global_variables_initializer()
    sess.run(init)
    output=tf.argmax(pred,1)
    batch_xs,batch_ys=mnist.train.next_batch(2)
    outputval,predv=sess.run([output,pred],feed_dict={x:batch_xs})
print(outputval,predv,batch_ys)

#画图
im=batch_xs[0]
im=im.reshape(-1,28)
pylab.imshow(im)  #绘制图片
pylab.show()

im=batch_xs[1]
im=im.reshape(-1,28)
pylab.imshow(im)  #绘制图片
pylab.show()














